﻿RepostGuard Lite — Galaxy S23 Ultra 手机测试图 v1

内容：
- blind/：30 张盲测图片，REAL 与 AIGI 各 15 张。
- answer_key.csv：答案、来源切片、桌面端 Student 分数和文件哈希。
- selection_manifest.json：确定性抽样方法。

建议测试方式：
1. 先只打开 blind 文件夹，按 RG_001、RG_002…依次在 App 中检测。
2. 记录 App 显示的 AIGI 分数、预处理耗时和推理耗时。
3. 测完后再打开 answer_key.csv 对答案，并比较 student_desktop_score。

说明：
- 该包是诊断集，不是随机抽样，也不能替代完整数据集指标。
- 每个切片同时包含 easy 和 stress 样本；主验证切片还包含 borderline 样本。
- 只使用已有评估 manifest，未使用训练集或任何私有官方最终测试数据。
- 图片仅供团队内部比赛测试，请勿公开再分发。
